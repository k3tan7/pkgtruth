def message():
    return "changed after RECORD was written"
